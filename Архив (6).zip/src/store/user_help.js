export default class User{
	constructor(id){
		this.id = id;
	}
}